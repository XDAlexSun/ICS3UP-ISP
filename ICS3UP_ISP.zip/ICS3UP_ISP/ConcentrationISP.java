// The "ConcentrationISP" class.
/*
Names: Alex Sun & David Shim
Program Name: ConcentrationISP.java
Teacher: Mrs. Krasteva
Dates: January 17, 2021 - January 29, 2021
Assignment: ICS3UP Final ISP - Concentration:
	    Two player game in which 2 players take turns matching cards. If the cards match the player
	    is rewarded with one point. The program includes other screens as well in the program
	    that run logically using a main menu screen.
*/
import java.awt.*;
import hsa.Console;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.util.Arrays;
import hsa.*;
import java.io.*;
import javax.imageio.ImageIO;
import java.awt.image.*;
import java.util.*;

public class ConcentrationISP
{
    //variable dictionary
    /*
    -------------------------------------------------------------------------------------------------------------
    |   Name        |   Type        |   Purpose                                                                 |
    -------------------------------------------------------------------------------------------------------------
    | menuOption    | int           | This is a simple hover variable that draws a circle next to the current   |
    |               |               | choice of the user for clarity.                                           |
    -------------------------------------------------------------------------------------------------------------
    | easyItems     | int [][]      | To store the value of the icon. This was originally inteded to be a       |
    |               |               | 2D String array, however, switch cases do not work with String on this    |
    |               |               | Version of Java. Essentially, this array will be shuffled and used for    |
    |               |               | comparison and drawing icons for the easy mode of the game. (4 x 4)       |
    -------------------------------------------------------------------------------------------------------------
    | mediumItems   | int [][]      | To store the value of the icon. This was originally inteded to be a       |
    |               |               | 2D String array, however, switch cases do not work with String on this    |
    |               |               | Version of Java. Essentially, this array will be shuffled and used for    |
    |               |               | comparison and drawing icons for the medium mode of the game. (6 x 6)     |
    -------------------------------------------------------------------------------------------------------------
    | hardItems     | int [][]      | To store the value of the icon. This was originally inteded to be a       |
    |               |               | 2D String array, however, switch cases do not work with String on this    |
    |               |               | Version of Java. Essentially, this array will be shuffled and used for    |
    |               |               | comparison and drawing icons for the hard mode of the game. (8 x 8)       |
    -------------------------------------------------------------------------------------------------------------
    | easyFlip      | boolean [][]  | This 2D boolean array stores whether a card is flipped or not, which      |
    |               |               | checks whether or not the program should display the front or back of     |
    |               |               | a certain card. Additionally, if, at any given time, any two of the       |
    |               |               | elements are equal to true. The program will check whether or not the     |
    |               |               | to give the user a point. This is used on the easy version of the game.   |
    -------------------------------------------------------------------------------------------------------------
    | meidumFlip    | boolean [][]  | This 2D boolean array stores whether a card is flipped or not, which      |
    |               |               | checks whether or not the program should display the front or back of     |
    |               |               | a certain card. Additionally, if, at any given time, any two of the       |
    |               |               | elements are equal to true. The program will check whether or not the     |
    |               |               | to give the user a point. This is used on the medium version of the game. |
    -------------------------------------------------------------------------------------------------------------
    | hardFlip      | boolean [][]  | This 2D boolean array stores whether a card is flipped or not, which      |
    |               |               | checks whether or not the program should display the front or back of     |
    |               |               | a certain card. Additionally, if, at any given time, any two of the       |
    |               |               | elements are equal to true. The program will check whether or not the     |
    |               |               | to give the user a point. This is used on the hard version of the game.   |
    -------------------------------------------------------------------------------------------------------------
    | easyFlip2     | boolean [][]  | This 2D boolean array exists simply to show the cards of the array that   |
    |               |               | have already been found and to end the game if all its elements are true. |
    -------------------------------------------------------------------------------------------------------------
    | mediumFlip2   | boolean [][]  | This 2D boolean array exists simply to show the cards of the array that   |
    |               |               | have already been found and to end the game if all its elements are true. |
    -------------------------------------------------------------------------------------------------------------
    | hardFlip2     | boolean [][]  | This 2D boolean array exists simply to show the cards of the array that   |
    |               |               | have already been found and to end the game if all its elements are true. |
    -------------------------------------------------------------------------------------------------------------
    | easyXTemp     | int[]         | In the easy mode of the game, when the user presses enter, the x-value of |
    |               |               | the card is saved into this array twice. This variable is crucial later on|
    |               |               | to check if the user receives a point or not.                             |
    -------------------------------------------------------------------------------------------------------------
    | medumXTemp    | int[]         | In the medium mode of the game, when the user presses enter, the x-value  |
    |               |               | of the card is saved into this array twice. This variable is crucial later|
    |               |               | on to check if the user receives a point or not.                          |
    -------------------------------------------------------------------------------------------------------------
    | hardXTemp     | int[]         | In the hard mode of the game, when the user presses enter, the x-value of |
    |               |               | the card is saved into this array twice. This variable is crucial later on|
    |               |               | to check if the user receives a point or not.                             |
    -------------------------------------------------------------------------------------------------------------
    | easyYTemp     | int[]         | In the easy mode of the game, when the user presses enter, the y-value of |
    |               |               | the card is saved into this array twice. This variable is crucial later on|
    |               |               | to check if the user receives a point or not.                             |
    -------------------------------------------------------------------------------------------------------------
    | medumYTemp    | int[]         | In the medium mode of the game, when the user presses enter, the y-value  |
    |               |               | of the card is saved into this array twice. This variable is crucial later|
    |               |               | on to check if the user receives a point or not.                          |
    -------------------------------------------------------------------------------------------------------------
    | hardYTemp     | int[]         | In the hard mode of the game, when the user presses enter, the y-value of |
    |               |               | the card is saved into this array twice. This variable is crucial later on|
    |               |               | to check if the user receives a point or not.                             |
    -------------------------------------------------------------------------------------------------------------
    | difficulty    | int           | This variable simply changes the difficulty of the game and must be global|
    |               |               | because many methods depend on this variable. Its value can be changed in |
    |               |               | the mainMenu method.                                                      |
    -------------------------------------------------------------------------------------------------------------
    | turn          | int           | Turn works in conjunction with all the temp arrays as it determines which |
    |               |               | index to store a variable. It is decreased and increased with enter and if|
    |               |               | it reaches greater or equal to 2, the program checks if the two selected  |
    |               |               | cards are equal and gives points accordingly.                             |
    -------------------------------------------------------------------------------------------------------------
    | playerTurn    | int           | This variable determines which player's turn it is and will display       |
    |               |               | different images depending on if it is odd or even. It also dictates which|
    |               |               | player will receive points if a matching pair was found.                  |
    -------------------------------------------------------------------------------------------------------------
    | player1Points | int           | This variable keeps track of how many points player 1 has.                |
    -------------------------------------------------------------------------------------------------------------
    | player2Points | int           | This variable keeps track of how many points player 2 has.                |
    -------------------------------------------------------------------------------------------------------------
    | game          | boolean       | Boolean game determines if the game should keep running                   |
    -------------------------------------------------------------------------------------------------------------
    */
    static Console c;           // The output console
    int menuOption = 1;
    //in these arrays, an integer will represent an icon
    int[] [] easyItems = {
	    {1, 1, 2, 2},
	    {3, 3, 4, 4},
	    {5, 5, 6, 6},
	    {7, 7, 8, 8}
	};
    /*
    As mentioned in the variable dictionary, each integer represents an icon and this is the list:
	    1 - helmet
	    2 - dragon
	    3 - princess
	    4 - unicorn
	    5 - griffin
	    6 - fairy
	    7 - goblin
	    8 - spider
	    9 - devil
	    10 - elf
	    11 - mage
	    12 - ghost
	    13 - fire
	    14 - water
	    15 - slime
	    16 - minotaur
	    17 - mimic
	    18 - ganon
	    19 - sword
	    20 - shield
	    21 - magic wand
	    22 - dragon egg
	    23 - goldbag
	    24 - centaur
	    25 - bow
	    26 - potion
	    27 - wizard hat
	    28 - gargoyle
	    29 - crown
	    30 - skeleton
	    31 - nimbus
	    32 - rune
    */
    int[] [] mediumItems = {
	    {1, 1, 2, 2, 9, 9},
	    {3, 3, 4, 4, 10, 10},
	    {5, 5, 6, 6, 11, 11},
	    {7, 7, 8, 8, 12, 12},
	    {13, 13, 14, 14, 15, 15},
	    {16, 16, 17, 17, 18, 18},
	};
    int[] [] hardItems = {
	    {1, 1, 19, 19, 2, 2, 15, 15},
	    {3, 3, 16, 16, 4, 4, 20, 20},
	    {5, 5, 21, 21, 6, 6, 22, 22},
	    {7, 7, 23, 23, 8, 8, 24, 24},
	    {9, 9, 25, 25, 12, 12, 26, 26},
	    {10, 10, 27, 27, 11, 11, 28, 28},
	    {13, 13, 29, 29, 14, 14, 30, 30},
	    {17, 17, 31, 31, 18, 18, 32, 32}
	};
    boolean[] [] easyFlip = {
	    {false, false, false, false},
	    {false, false, false, false},
	    {false, false, false, false},
	    {false, false, false, false}
	};
    boolean[] [] mediumFlip = {
	    {false, false, false, false, false, false},
	    {false, false, false, false, false, false},
	    {false, false, false, false, false, false},
	    {false, false, false, false, false, false},
	    {false, false, false, false, false, false},
	    {false, false, false, false, false, false}
	};
    boolean[] [] hardFlip = {
	    {false, false, false, false, false, false, false, false},
	    {false, false, false, false, false, false, false, false},
	    {false, false, false, false, false, false, false, false},
	    {false, false, false, false, false, false, false, false},
	    {false, false, false, false, false, false, false, false},
	    {false, false, false, false, false, false, false, false},
	    {false, false, false, false, false, false, false, false},
	    {false, false, false, false, false, false, false, false}
	};
    boolean[] [] easyFlip2 = {
	    {false, false, false, false},
	    {false, false, false, false},
	    {false, false, false, false},
	    {false, false, false, false}
	};
    boolean[] [] mediumFlip2 = {
	    {false, false, false, false, false, false},
	    {false, false, false, false, false, false},
	    {false, false, false, false, false, false},
	    {false, false, false, false, false, false},
	    {false, false, false, false, false, false},
	    {false, false, false, false, false, false}
	};
    boolean[] [] hardFlip2 = {
	    {false, false, false, false, false, false, false, false},
	    {false, false, false, false, false, false, false, false},
	    {false, false, false, false, false, false, false, false},
	    {false, false, false, false, false, false, false, false},
	    {false, false, false, false, false, false, false, false},
	    {false, false, false, false, false, false, false, false},
	    {false, false, false, false, false, false, false, false},
	    {false, false, false, false, false, false, false, false}
	};
    int[] easyXTemp = {0, 0};
    int[] mediumXTemp = {0, 0};
    int[] hardXTemp = {0, 0};
    int[] easyYTemp = {0, 0};
    int[] mediumYTemp = {0, 0};
    int[] hardYTemp = {0, 0};
    int difficulty = 1;
    int turn = 0;
    int playerTurn = 0;
    int player1Points = 0;
    int player2Points = 0;
    boolean game = false;

    public ConcentrationISP ()
    {
	c = new Console (33, 150);
    }


    /*
    Method name: drawBackground
    Purpose: To draw the backgrounds of mainMenu and difficultySelector
    Variables:
    -------------------------------------------------------------------------------------------------------------
    |   Name        |   Type        |   Purpose                                                                 |
    -------------------------------------------------------------------------------------------------------------
    | castle        | bufferedImage | To draw the castle in the background.                                     |
    -------------------------------------------------------------------------------------------------------------
    | menuScroll    | bufferedImage | To draw the scroll containing mainMenu info.                              |
    -------------------------------------------------------------------------------------------------------------
    Try block: It is required to draw images properly.
    */
    public void drawBackground ()
    {
	try
	{
	    BufferedImage castle = ImageIO.read (new File ("images//background0.png"));
	    BufferedImage menuScroll = ImageIO.read (new File ("images//scroll1.png"));
	    c.drawImage (castle, 0, 0, null);
	    c.drawImage (menuScroll, 0, 80, null);
	}
	catch (IOException e)
	{
	    c.println ("No image found");
	}
	c.setColor (Color.RED);
	c.setFont (new Font ("Times New Roman", 100, 70));
	c.drawString ("Concentration: Fantasia", 500, 60);
    }


    /*
    Method name: pauseProgram
    Purpose: To allow the program to stop until the user inputs a char.
    */
    private void pauseProgram ()
    {
	c.setColor (Color.white);
	c.setFont (new Font ("Times New Roman", 12, 20));
	c.drawString ("Press any key to continue", 50, 600);
	c.getChar ();
	c.clear ();
    }


    /*
    Method name: splashScreen
    Purpose: A loading screen or "intro" for our game that makes the user wait before having the game load in.
    Variables:
    -------------------------------------------------------------------------------------------------------------
    |   Name        |   Type        |   Purpose                                                                 |
    -------------------------------------------------------------------------------------------------------------
    |  x, w, a, e, g|   int[]       |   Holds the values of the x coordinates of a polygon of my choice         |
    -------------------------------------------------------------------------------------------------------------
    |  y, v, b, f, h|   int[]       |   Holds the values of the y coordinates of a polygon of my choice         |
    -------------------------------------------------------------------------------------------------------------
    for loop: Used to make the screen animated while the whole screen us just redrawn but with different coordinates for each frame
    try block: Used to determine the frame rate of the animation
    */
    public void splashScreen ()
    {
	for (int i = 100 ; i > 0 ; i--)
	{
	    Color background = new Color (52, 25, 0);
	    c.setColor (background);
	    c.fillRect (0, 0, 1300, 800);
	    c.setColor (Color.white);
	    c.setFont (new Font ("Times New Roman", 12, 70));
	    c.drawString ("Fantasia", 20, 60);
	    c.setFont (new Font ("Times New Roman", 12, 20));
	    c.drawString ("A game of dreams and imagination", 20, 90);
	    int x[] = {550, 750, 950, 850, 750, 650};
	    int y[] = {450, 550, 450, 200, 150, 200};
	    Color mountain = new Color (160, 160, 160);
	    c.setColor (mountain);
	    c.fillPolygon (x, y, 6);
	    c.setColor (Color.black);
	    int w[] = {550, 750, 950, 850, 750, 650};
	    int v[] = {450, 550, 450, 200, 250, 200};
	    c.drawPolygon (w, v, 6);
	    c.drawLine (750, 100, 750, 550);
	    c.drawLine (850, 200, 750, 235);
	    c.drawLine (650, 200, 750, 235);
	    c.setColor (Color.blue);
	    int a[] = {630, 660, 750, 840, 870, 890, 850, 750, 640, 610};
	    int b[] = {250, 350, 300, 350, 250, 300, 400, 350, 400, 300};
	    c.fillPolygon (a, b, 10);
	    int e[] = {750, 850, 750, 650};
	    int f[] = {i + 200, i + 100, i, i + 100};
	    Color Crystal = new Color (102, 255, 255);
	    c.setColor (Crystal);
	    c.fillPolygon (e, f, 4);
	    c.setColor (Color.black);
	    c.drawLine (750, i + 200, 750, i);
	    c.drawLine (650, i + 100, 750, i + 140);
	    c.drawLine (850, i + 100, 750, i + 140);
	    int g[] = {850, 750, 650, 750};
	    int h[] = {200, 300, 200, 250};
	    c.setColor (mountain);
	    c.fillPolygon (g, h, 4);
	    c.setColor (Color.black);
	    c.drawLine (750, 100, 750, 550);
	    try
	    {
		Thread.sleep (100);
	    }
	    catch (Exception c)
	    {
	    }
	}
	pauseProgram ();
    }


    /*
    Method name: mainMenu
    Purpose: To make a main menu with 4 options: play game, view instructions, view leaderboard, and exit the game
    Variables:
    -------------------------------------------------------------------------------------------------------------
    |   Name        |   Type        |   Purpose                                                                 |
    -------------------------------------------------------------------------------------------------------------
    | choice        | char          | choice is a character key inputted by the user and each value will do     |
    |               |               | somehting different.                                                      |
    -------------------------------------------------------------------------------------------------------------
    While loop: While loop is used so the user must input something before they may proceed so the program will keep
		looping until the user chooses an option.
    If - else: This long if - else structure is what controls paramaters for input. It controls what each input of
	       char choice does and helps with clarity for using the main menu.
    */
    public void mainMenu ()
    {
	char choice;
	while (true)    //have to loop the menu until the user gives valid input
	{
	    drawBackground ();
	    c.setColor (Color.BLACK);
	    choice = ' ';
	    c.setFont (new Font ("Times New Roman", 100, 46));
	    c.drawString ("Main Menu", 100, 170);
	    c.setFont (new Font ("Times New Roman", 100, 30));
	    c.drawString ("Play", 100, 220);
	    c.drawString ("Instructions", 100, 270);
	    c.drawString ("High Score", 100, 320);
	    c.drawString ("Exit", 100, 370);
	    if (menuOption == 1)
	    {
		c.fillOval (70, 200, 20, 20);
		choice = c.getChar ();
		if (choice == 's' || choice == 'S')
		{
		    menuOption = 2;
		}
		else if (choice == '\n')
		{
		    menuOption = 1;
		    break;
		}
	    }
	    else if (menuOption == 2)
	    {
		c.fillOval (70, 250, 20, 20);
		choice = c.getChar ();
		if (choice == 'w' || choice == 'W')
		{
		    menuOption = 1;
		}
		else if (choice == 's' || choice == 'S')
		{
		    menuOption = 3;
		}
		else if (choice == '\n')
		{
		    menuOption = 2;
		    break;
		}
	    }
	    else if (menuOption == 3)
	    {
		c.fillOval (70, 300, 20, 20);
		choice = c.getChar ();
		if (choice == 'w' || choice == 'W')
		{
		    menuOption = 2;
		}
		else if (choice == 's' || choice == 'S')
		{
		    menuOption = 4;
		}
		else if (choice == '\n')
		{
		    menuOption = 3;
		    break;
		}
	    }
	    else if (menuOption == 4)
	    {
		c.fillOval (70, 350, 20, 20);
		choice = c.getChar ();
		if (choice == 'w' || choice == 'W')
		{
		    menuOption = 3;
		}
		else if (choice == '\n')
		{
		    menuOption = 4;
		    break;
		}
	    }
	}
    }


    /*
    Method name: difficultySelector
    Purpose: To make a difficulty menu with 4 modes: easy, medium, hard
    Variables:
    -------------------------------------------------------------------------------------------------------------
    |   Name        |   Type        |   Purpose                                                                 |
    -------------------------------------------------------------------------------------------------------------
    | choice2       | char         | choice2 is a character key inputted by the user and each value will do     |
    |               |               | something different.                                                      |
    -------------------------------------------------------------------------------------------------------------
    While loop: While loop is used so the user must input something before they may proceed so the program will keep
		looping until the user chooses an option.
    If - else: This long if - else structure is what controls paramaters for input. It controls what each input of
	       char choice does and helps with clarity for using the difficulty selector.
    */
    public void difficultySelector ()
    {
	char choice2;
	while (true)
	{
	    drawBackground ();
	    c.setColor (Color.BLACK);
	    choice2 = ' ';
	    c.setFont (new Font ("Times New Roman", 100, 36));
	    c.drawString ("Difficulty Selector", 70, 170);
	    c.setFont (new Font ("Times New Roman", 100, 30));
	    c.drawString ("Easy", 100, 220);
	    c.drawString ("Medium", 100, 270);
	    c.drawString ("Hard", 100, 320);
	    if (difficulty == 1)
	    {
		c.fillOval (70, 200, 20, 20);
		choice2 = c.getChar ();
		if (choice2 == 's' || choice2 == 'S')
		{
		    difficulty = 2;
		}
		else if (choice2 == '\n')
		{
		    difficulty = 1;
		    break;
		}
	    }
	    else if (difficulty == 2)
	    {
		c.fillOval (70, 250, 20, 20);
		choice2 = c.getChar ();
		if (choice2 == 'w' || choice2 == 'W')
		{
		    difficulty = 1;
		}
		else if (choice2 == 's' || choice2 == 'S')
		{
		    difficulty = 3;
		}
		else if (choice2 == '\n')
		{
		    difficulty = 2;
		    break;
		}
	    }
	    else if (difficulty == 3)
	    {
		c.fillOval (70, 300, 20, 20);
		choice2 = c.getChar ();
		if (choice2 == 'w' || choice2 == 'W')
		{
		    difficulty = 2;
		}
		else if (choice2 == '\n')
		{
		    difficulty = 3;
		    break;
		}
	    }
	}
    }


    /*
    Method Name: Swap
    Purpose: To randomly swap the elements of an array
    Variables:
    -------------------------------------------------------------------------------------------------------------
    |   Name        |   Type        |   Purpose                                                                 |
    -------------------------------------------------------------------------------------------------------------
    | arr           | int [] []     | This is the array that will be shuffled.                                  |
    -------------------------------------------------------------------------------------------------------------
    | i             | int           | One of the variables that control what index the array is currently at.   |
    -------------------------------------------------------------------------------------------------------------
    | j             | int           | One of the variables that control what index the array is currently at.   |
    -------------------------------------------------------------------------------------------------------------
    | x             | int           | One of the variables that control what index the array is currently at.   |
    -------------------------------------------------------------------------------------------------------------
    | y             | int           | One of the variables that control what index the array is currently at.   |
    -------------------------------------------------------------------------------------------------------------
    | tmp             | int         | Temporarily holds the array element while it is being swapped.            |
    -------------------------------------------------------------------------------------------------------------
    */
    private static void swap (int[] [] arr, int i, int j, int x, int y)
    {
	int tmp = arr [i] [j];
	arr [i] [j] = arr [x] [y];
	arr [x] [y] = tmp;
    }


    /*
    Method Name: deckShuffle
    Purpose: To randomly swap the elements of an array
    Variables:
    -------------------------------------------------------------------------------------------------------------
    |   Name        |   Type        |   Purpose                                                                 |
    -------------------------------------------------------------------------------------------------------------
    | row           | int           | This variable holds the current x index of the 2D array being shuffled.   |
    -------------------------------------------------------------------------------------------------------------
    | col           | int           | This variable holds the current y index of the 2D array being shuffled.   |
    -------------------------------------------------------------------------------------------------------------
    | swp           | int           | This variable holds the new value of the index.                           |
    -------------------------------------------------------------------------------------------------------------
    | srow          | int           | This variable holds the new x index of the 2D array being shuffled.       |
    -------------------------------------------------------------------------------------------------------------
    | scol          | int           | This variable holds the new y index of the 2D array being shuffled.       |
    -------------------------------------------------------------------------------------------------------------
    */
    public void deckShuffle ()  //Credit to Leyang for providing shuffle array algorithm (fisher-yates, I wasn't sure how to implement it properly until he better explained it
	//the reason why i was unable to implement it was because I did not properly look over the code and didn't use a temp variable
    {
	if (difficulty == 1)
	{
	    for (int i = 0 ; i < 16 ; ++i)
	    {
		int row = i / 4;
		int col = i % 4;
		int swp = i + (int) (Math.random () * (16 - i));
		int srow = swp / 4;
		int scol = swp % 4;
		swap (easyItems, row, col, srow, scol);
	    }
	}
	else if (difficulty == 2)
	{
	    for (int i = 0 ; i < 36 ; ++i)
	    {
		int row = i / 6;
		int col = i % 6;
		int swp = i + (int) (Math.random () * (36 - i));
		int srow = swp / 6;
		int scol = swp % 6;
		swap (mediumItems, row, col, srow, scol);
	    }
	}
	else if (difficulty == 3)
	{
	    for (int i = 0 ; i < 64 ; ++i)
	    {
		int row = i / 8;
		int col = i % 8;
		int swp = i + (int) (Math.random () * (64 - i));
		int srow = swp / 8;
		int scol = swp % 8;
		swap (hardItems, row, col, srow, scol);
	    }
	}
    }


    /*
    Method: showCards
    Purpose: To show the user the icons before flipping them back to start the game
    Try - catch: A try - catch block is required for image importing
    For loops - since the data is stored in a 2D array, a nested for loop is required
		to properly access it

    */
    public void showCards ()
    {
	try
	{
	    BufferedImage castle = ImageIO.read (new File ("images//background1.png"));
	    c.drawImage (castle, 0, 0, null);
	}
	catch (IOException e)
	{
	    c.println ("No image found");
	}
	if (difficulty == 1)
	{
	    for (int i = 0 ; i < 4 ; i++)
	    {
		for (int j = 0 ; j < 4 ; j++)
		{
		    try
		    {
			BufferedImage easyFront = ImageIO.read (new File ("images//easyFront.png"));

			c.drawImage (easyFront, 360 + i * 145, 10 + j * 165, null);
		    }
		    catch (IOException e)
		    {
			c.println ("No image found");
		    }
		    drawIcons (easyItems [i] [j], 395 + i * 145, 45 + j * 165);
		}
	    }
	}
	else if (difficulty == 2)
	{
	    for (int i = 0 ; i < 6 ; i++)
	    {
		for (int j = 0 ; j < 6 ; j++)
		{
		    try
		    {
			BufferedImage mediumFront = ImageIO.read (new File ("images//mediumFront.png"));
			c.drawImage (mediumFront, 330 + i * 93, 10 + j * 108, null);
		    }
		    catch (IOException e)
		    {
			c.println ("No image found");
		    }
		    drawIcons (mediumItems [i] [j], 338 + i * 93, 23 + j * 108);
		}
	    }

	}
	else if (difficulty == 3)
	{
	    for (int i = 0 ; i < 8 ; i++)
	    {
		for (int j = 0 ; j < 8 ; j++)
		{
		    try
		    {
			BufferedImage hardFront = ImageIO.read (new File ("images//hardFront.png"));
			c.drawImage (hardFront, 340 + i * 70, 15 + j * 81, null);
		    }
		    catch (IOException e)
		    {
			c.println ("No image found");
		    }
		    drawIcons (hardItems [i] [j], 340 + i * 70, 20 + j * 81);
		}

	    }
	}
    }


    /*
    Method Name: drawIcons
    Purpose: Since the values of the icons are integers, this method reads all of them and outputs
	     a corresponding icon
    Switch - case: Using a switch structure, I won't have to tediously write out 32 if statements
    */
    private void drawIcons (int icon, int x, int y)
    {
	switch (icon)
	{
	    case 1:
		try
		{
		    BufferedImage helmet = ImageIO.read (new File ("images//helmet.png"));
		    c.drawImage (helmet, x, y, null);
		}
		catch (IOException e)
		{
		    c.println ("No image found");
		}
		break;
	    case 2:
		try
		{
		    BufferedImage dragon = ImageIO.read (new File ("images//dragon.png"));
		    c.drawImage (dragon, x, y, null);
		}
		catch (IOException e)
		{
		    c.println ("No image found");
		}
		break;
	    case 3:
		try
		{
		    BufferedImage princess = ImageIO.read (new File ("images//princess.png"));
		    c.drawImage (princess, x, y - 5, null);
		}
		catch (IOException e)
		{
		    c.println ("No image found");
		}
		break;
	    case 4:
		try
		{
		    BufferedImage unicorn = ImageIO.read (new File ("images//unicorn.png"));
		    c.drawImage (unicorn, x, y, null);
		}
		catch (IOException e)
		{
		    c.println ("No image found");
		}
		break;
	    case 5:
		try
		{
		    BufferedImage griffin = ImageIO.read (new File ("images//griffin.png"));
		    c.drawImage (griffin, x, y, null);
		}
		catch (IOException e)
		{
		    c.println ("No image found");
		}
		break;
	    case 6:
		try
		{
		    BufferedImage fairy = ImageIO.read (new File ("images//fairy.png"));
		    c.drawImage (fairy, x, y, null);
		}
		catch (IOException e)
		{
		    c.println ("No image found");
		}
		break;
	    case 7:
		try
		{
		    BufferedImage goblin = ImageIO.read (new File ("images//goblin.png"));
		    c.drawImage (goblin, x, y, null);
		}
		catch (IOException e)
		{
		    c.println ("No image found");
		}
		break;
	    case 8:
		try
		{
		    BufferedImage spider = ImageIO.read (new File ("images//spider.png"));
		    c.drawImage (spider, x + 8, y + 8, null);
		}
		catch (IOException e)
		{
		    c.println ("No image found");
		}
		break;
	    case 9:
		try
		{
		    BufferedImage devil = ImageIO.read (new File ("images//devil.png"));
		    c.drawImage (devil, x, y, null);
		}
		catch (IOException e)
		{
		    c.println ("No image found");
		}
		break;
	    case 10:
		try
		{
		    BufferedImage elf = ImageIO.read (new File ("images//elf.png"));
		    c.drawImage (elf, x - 2, y - 2, null);
		}
		catch (IOException e)
		{
		    c.println ("No image found");
		}
		break;
	    case 11:
		try
		{
		    BufferedImage mage = ImageIO.read (new File ("images//mage.png"));
		    c.drawImage (mage, x, y, null);
		}
		catch (IOException e)
		{
		    c.println ("No image found");
		}
		break;
	    case 12:
		try
		{
		    BufferedImage ghost = ImageIO.read (new File ("images//ghost.png"));
		    c.drawImage (ghost, x, y, null);
		}
		catch (IOException e)
		{
		    c.println ("No image found");
		}
		break;
	    case 13:
		try
		{
		    BufferedImage fire = ImageIO.read (new File ("images//fire.png"));
		    c.drawImage (fire, x, y, null);
		}
		catch (IOException e)
		{
		    c.println ("No image found");
		}
		break;
	    case 14:
		try
		{
		    BufferedImage water = ImageIO.read (new File ("images//water.png"));
		    c.drawImage (water, x, y, null);
		}
		catch (IOException e)
		{
		    c.println ("No image found");
		}
		break;
	    case 15:
		try
		{
		    BufferedImage slime = ImageIO.read (new File ("images//slime.png"));
		    c.drawImage (slime, x + 1, y + 10, null);
		}
		catch (IOException e)
		{
		    c.println ("No image found");
		}
		break;
	    case 16:
		try
		{
		    BufferedImage minotaur = ImageIO.read (new File ("images//minotaur.png"));
		    c.drawImage (minotaur, x, y, null);
		}
		catch (IOException e)
		{
		    c.println ("No image found");
		}
		break;
	    case 17:
		try
		{
		    BufferedImage mimic = ImageIO.read (new File ("images//mimic.png"));
		    c.drawImage (mimic, x, y, null);
		}
		catch (IOException e)
		{
		    c.println ("No image found");
		}
		break;
	    case 18:
		try
		{
		    BufferedImage ganon = ImageIO.read (new File ("images//ganon.png"));
		    c.drawImage (ganon, x, y, null);
		}
		catch (IOException e)
		{
		    c.println ("No image found");
		}
		break;

	    case 19:
		try
		{
		    BufferedImage sword = ImageIO.read (new File ("images//sword.png"));
		    c.drawImage (sword, x, y, null);
		}
		catch (IOException e)
		{
		    c.println ("No image found");
		}
		break;
	    case 20:
		try
		{
		    BufferedImage shield = ImageIO.read (new File ("images//shield.png"));
		    c.drawImage (shield, x, y, null);
		}
		catch (IOException e)
		{
		    c.println ("No image found");
		}
		break;
	    case 21:
		try
		{
		    BufferedImage wand = ImageIO.read (new File ("images//wand.png"));
		    c.drawImage (wand, x, y, null);
		}
		catch (IOException e)
		{
		    c.println ("No image found");
		}
		break;
	    case 22:
		try
		{
		    BufferedImage egg = ImageIO.read (new File ("images//egg.png"));
		    c.drawImage (egg, x + 8, y + 8, null);
		}
		catch (IOException e)
		{
		    c.println ("No image found");
		}
		break;
	    case 23:
		try
		{
		    BufferedImage goldbag = ImageIO.read (new File ("images//goldbag.png"));
		    c.drawImage (goldbag, x, y, null);
		}
		catch (IOException e)
		{
		    c.println ("No image found");
		}
		break;
	    case 24:
		try
		{
		    BufferedImage centaur = ImageIO.read (new File ("images//centaur.png"));
		    c.drawImage (centaur, x - 2, y - 2, null);
		}
		catch (IOException e)
		{
		    c.println ("No image found");
		}
		break;
	    case 25:
		try
		{
		    BufferedImage bow = ImageIO.read (new File ("images//bow.png"));
		    c.drawImage (bow, x, y, null);
		}
		catch (IOException e)
		{
		    c.println ("No image found");
		}
		break;
	    case 26:
		try
		{
		    BufferedImage potion = ImageIO.read (new File ("images//potion.png"));
		    c.drawImage (potion, x, y, null);
		}
		catch (IOException e)
		{
		    c.println ("No image found");
		}
		break;
	    case 27:
		try
		{
		    BufferedImage hat = ImageIO.read (new File ("images//hat.png"));
		    c.drawImage (hat, x, y, null);
		}
		catch (IOException e)
		{
		    c.println ("No image found");
		}
		break;
	    case 28:
		try
		{
		    BufferedImage gargoyle = ImageIO.read (new File ("images//gargoyle.png"));
		    c.drawImage (gargoyle, x, y, null);
		}
		catch (IOException e)
		{
		    c.println ("No image found");
		}
		break;
	    case 29:
		try
		{
		    BufferedImage crown = ImageIO.read (new File ("images//crown.png"));
		    c.drawImage (crown, x, y, null);
		}
		catch (IOException e)
		{
		    c.println ("No image found");
		}
		break;
	    case 30:
		try
		{
		    BufferedImage skeleton = ImageIO.read (new File ("images//skeleton.png"));
		    c.drawImage (skeleton, x, y, null);
		}
		catch (IOException e)
		{
		    c.println ("No image found");
		}
		break;
	    case 31:
		try
		{
		    BufferedImage nimbus = ImageIO.read (new File ("images//mimic.png"));
		    c.drawImage (nimbus, x, y, null);
		}
		catch (IOException e)
		{
		    c.println ("No image found");
		}
		break;
	    case 32:
		try
		{
		    BufferedImage rune = ImageIO.read (new File ("images//rune.png"));
		    c.drawImage (rune, x, y, null);
		}
		catch (IOException e)
		{
		    c.println ("No image found");
		}
		break;

	}
    }


    /*
    Method Name: concentration
    Purpose: Draws the level and contains the actual game with input
    Variables:
    -------------------------------------------------------------------------------------------------------------
    |   Name        |   Type        |   Purpose                                                                 |
    -------------------------------------------------------------------------------------------------------------
    | playerX       | int           | Contains the current x - index of the array the user is currently at. This|
    |               |               | value is changed using the 'a' and 'd' keys.                              |
    -------------------------------------------------------------------------------------------------------------
    | playerY       | int           | Contains the current y - index of the array the user is currently at. This|
    |               |               | value is changed using the 'w' and 's' keys.                              |
    -------------------------------------------------------------------------------------------------------------
    | choice3       | char          | choice3 is a character key inputted by the user and each value will do    |
    |               |               | something different.                                                      |
    -------------------------------------------------------------------------------------------------------------
    While loop: While loop is used so the user must input something before they may proceed so the program will keep
		looping until the user chooses an option.
    If - else: This long if - else structure is what controls paramaters for input. It controls what each input of
	       char choice does and helps with clarity for using the main menu.
	       An if statement is used to see if the two players beat the level and the program should move on.
	       Another if - else structure is used to draw 2 separate characters depending on the turn of the user
    Try - catch: A try - catch block is required to import images properly

    The reason why this method is so long is because I tried making it in a separate method but it had issues running
    more than just once so I brute forced it and put it all in one giant method (Alex)
    */
    public void concentration ()
    {
	int playerX = 0;
	int playerY = 0;
	char choice3 = ' ';

	showCards ();
	//cover cards
	turnMaker ();
	try
	{
	    Thread.sleep (3000);
	}
	catch (InterruptedException e)
	{
	}
	while (true)
	{
	    try
	    {
		BufferedImage castle = ImageIO.read (new File ("images//background1.png"));
		c.drawImage (castle, 0, 0, null);
	    }
	    catch (IOException e)
	    {
		c.println ("No image found");
	    }
	    if (playerTurn % 2 == 0)
	    {
		try
		{
		    BufferedImage witcher = ImageIO.read (new File ("images//player1.png"));
		    c.drawImage (witcher, 0, 100, null);
		}
		catch (IOException e)
		{
		    c.println ("No image found");
		}
	    }
	    else
	    {
		try
		{
		    BufferedImage firemage = ImageIO.read (new File ("images//player2.png"));
		    c.drawImage (firemage, 870, 100, null);
		}
		catch (IOException e)
		{
		    c.println ("No image found");
		}
	    }
	    if (difficulty == 1)
	    {
		for (int i = 0 ; i < 4 ; i++)
		{
		    for (int j = 0 ; j < 4 ; j++)
		    {
			turnMaker ();
			flipCard (easyFlip [i] [j], easyItems [i] [j], i, j);
			if (turn < 1)
			    coverCard (easyFlip2 [i] [j], easyItems [i] [j], i, j);
		    }

		}
	    }
	    else if (difficulty == 2)
	    {
		for (int i = 0 ; i < 6 ; i++)
		{
		    for (int j = 0 ; j < 6 ; j++)
		    {
			turnMaker ();
			flipCard (mediumFlip [i] [j], mediumItems [i] [j], i, j);
			if (turn < 1)
			    coverCard (mediumFlip [i] [j], mediumItems [i] [j], i, j);
		    }
		}
	    }
	    else if (difficulty == 3)
	    {
		for (int i = 0 ; i < 8 ; i++)
		{
		    for (int j = 0 ; j < 8 ; j++)
		    {
			turnMaker ();
			flipCard (hardFlip [i] [j], hardItems [i] [j], i, j);
			if (turn < 1)
			    flipCard (hardFlip [i] [j], hardItems [i] [j], i, j);
		    }
		}
	    }


	    c.setColor (Color.RED);
	    if (difficulty == 1)
	    {
		c.drawRect (359 + playerX * 145, 10 + playerY * 165, 132, 156);
		endGame (easyFlip2);
		if (playerX == 0)
		{
		    choice3 = c.getChar ();
		    if (choice3 == 'w' || choice3 == 'W')
		    {
			--playerY;
		    }
		    else if (choice3 == 's' || choice3 == 'S')
		    {
			++playerY;
		    }
		    else if (choice3 == 'd' || choice3 == 'D')
		    {
			++playerX;
		    }
		    else if (choice3 == '\n' && easyFlip [playerX] [playerY] == false)
		    {
			easyFlip [playerX] [playerY] = true;
			easyXTemp [turn] = playerX;
			easyYTemp [turn] = playerY;
			++turn;
		    }
		    else if (choice3 == '\n' && easyFlip [playerX] [playerY] == true)
		    {
			easyFlip [playerX] [playerY] = false;
			turn = 0;
			easyXTemp [turn] = 0;
			easyYTemp [turn] = 0;
		    }
		}
		else if (playerY == 0)
		{
		    choice3 = c.getChar ();
		    if (choice3 == 'a' || choice3 == 'A')
		    {
			--playerX;
		    }
		    else if (choice3 == 's' || choice3 == 'S')
		    {
			++playerY;
		    }
		    else if (choice3 == 'd' || choice3 == 'D')
		    {
			++playerX;
		    }
		    else if (choice3 == '\n' && easyFlip [playerX] [playerY] == false)
		    {
			easyFlip [playerX] [playerY] = true;
			easyXTemp [turn] = playerX;
			easyYTemp [turn] = playerY;
			turn++;
		    }
		    else if (choice3 == '\n' && easyFlip [playerX] [playerY] == true)
		    {
			easyFlip [playerX] [playerY] = false;
			turn = 0;
			easyXTemp [turn] = 0;
			easyYTemp [turn] = 0;
		    }
		}
		else if (playerX > 0 && playerX < easyFlip.length - 1 && playerY > 0 && playerY < easyFlip [0].length - 1)
		{
		    choice3 = c.getChar ();
		    if (choice3 == 'w' || choice3 == 'W')
		    {
			--playerY;
		    }
		    else if (choice3 == 'a' || choice3 == 'A')
		    {
			--playerX;
		    }
		    else if (choice3 == 's' || choice3 == 'S')
		    {
			++playerY;
		    }
		    else if (choice3 == 'd' || choice3 == 'D')
		    {
			++playerX;
		    }
		    else if (choice3 == '\n' && easyFlip [playerX] [playerY] == false)
		    {
			easyFlip [playerX] [playerY] = true;
			easyXTemp [turn] = playerX;
			easyYTemp [turn] = playerY;
			++turn;
		    }
		    else if (choice3 == '\n' && easyFlip [playerX] [playerY] == true)
		    {
			easyFlip [playerX] [playerY] = false;
			turn = 0;
			easyXTemp [turn] = 0;
			easyYTemp [turn] = 0;
		    }
		}
		else if (playerX == easyFlip.length - 1)
		{
		    choice3 = c.getChar ();
		    if (choice3 == 'w' || choice3 == 'W')
		    {
			--playerY;
		    }
		    else if (choice3 == 's' || choice3 == 'S')
		    {
			++playerY;
		    }
		    else if (choice3 == 'a' || choice3 == 'A')
		    {
			--playerX;
		    }
		    else if (choice3 == '\n' && easyFlip [playerX] [playerY] == false)
		    {
			easyFlip [playerX] [playerY] = true;
			easyXTemp [turn] = playerX;
			easyYTemp [turn] = playerY;
			++turn;
		    }
		    else if (choice3 == '\n' && easyFlip [playerX] [playerY] == true)
		    {
			easyFlip [playerX] [playerY] = false;
			turn = 0;
			easyXTemp [turn] = 0;
			easyYTemp [turn] = 0;
		    }
		}
		else if (playerY == easyFlip.length - 1)
		{
		    choice3 = c.getChar ();
		    if (choice3 == 'a' || choice3 == 'A')
		    {
			--playerX;
		    }
		    else if (choice3 == 'w' || choice3 == 'W')
		    {
			--playerY;
		    }
		    else if (choice3 == 'd' || choice3 == 'D')
		    {
			++playerX;
		    }
		    else if (choice3 == '\n' && easyFlip [playerX] [playerY] == false)
		    {
			easyFlip [playerX] [playerY] = true;
			easyXTemp [turn] = playerX;
			easyYTemp [turn] = playerY;
			++turn;
		    }
		    else if (choice3 == '\n' && easyFlip [playerX] [playerY] == true)
		    {
			easyFlip [playerX] [playerY] = false;
			turn = 0;
			easyXTemp [turn] = 0;
			easyYTemp [turn] = 0;
		    }
		}
		if (turn >= 2)
		{
		    check (easyXTemp [0], easyYTemp [0], easyXTemp [1], easyYTemp [1]);
		    ++playerTurn;
		}
	    }
	    else if (difficulty == 2)
	    {
		endGame (mediumFlip2);
		c.drawRect (329 + playerX * 93, 10 + playerY * 108, 88, 104);
		if (playerX == 0)
		{
		    choice3 = c.getChar ();
		    if (choice3 == 'w' || choice3 == 'W')
		    {
			--playerY;
		    }
		    else if (choice3 == 's' || choice3 == 'S')
		    {
			++playerY;
		    }
		    else if (choice3 == 'd' || choice3 == 'D')
		    {
			++playerX;
		    }
		    else if (choice3 == '\n' && mediumFlip [playerX] [playerY] == false)
		    {
			mediumFlip [playerX] [playerY] = true;
			mediumXTemp [turn] = playerX;
			mediumYTemp [turn] = playerY;
			turn++;
		    }
		    else if (choice3 == '\n' && mediumFlip [playerX] [playerY] == true)
		    {
			mediumFlip [playerX] [playerY] = false;
			turn = 0;
			mediumXTemp [turn] = 0;
			mediumYTemp [turn] = 0;
		    }
		}
		else if (playerY == 0)
		{
		    choice3 = c.getChar ();
		    if (choice3 == 'a' || choice3 == 'A')
		    {
			--playerX;
		    }
		    else if (choice3 == 's' || choice3 == 'S')
		    {
			++playerY;
		    }
		    else if (choice3 == 'd' || choice3 == 'D')
		    {
			++playerX;
		    }
		    else if (choice3 == '\n' && mediumFlip [playerX] [playerY] == false)
		    {
			mediumFlip [playerX] [playerY] = true;
			mediumXTemp [turn] = playerX;
			mediumYTemp [turn] = playerY;
			turn++;
		    }
		    else if (choice3 == '\n' && mediumFlip [playerX] [playerY] == true)
		    {
			mediumFlip [playerX] [playerY] = false;
			turn = 0;
			mediumXTemp [turn] = 0;
			mediumYTemp [turn] = 0;
		    }
		}
		else if (playerX > 0 && playerX < mediumFlip.length - 1 && playerY > 0 && playerY < mediumFlip [0].length - 1)
		{
		    choice3 = c.getChar ();
		    if (choice3 == 'w' || choice3 == 'W')
		    {
			--playerY;
		    }
		    else if (choice3 == 'a' || choice3 == 'A')
		    {
			--playerX;
		    }
		    else if (choice3 == 's' || choice3 == 'S')
		    {
			++playerY;
		    }
		    else if (choice3 == 'd' || choice3 == 'D')
		    {
			++playerX;
		    }
		    else if (choice3 == '\n' && mediumFlip [playerX] [playerY] == false)
		    {
			mediumFlip [playerX] [playerY] = true;
			mediumXTemp [turn] = playerX;
			mediumYTemp [turn] = playerY;
			turn++;
		    }
		    else if (choice3 == '\n' && mediumFlip [playerX] [playerY] == true)
		    {
			mediumFlip [playerX] [playerY] = false;
			turn = 0;
			mediumXTemp [turn] = 0;
			mediumYTemp [turn] = 0;
		    }
		}
		else if (playerX == mediumFlip.length - 1)
		{
		    choice3 = c.getChar ();
		    if (choice3 == 'w' || choice3 == 'W')
		    {
			--playerY;
		    }
		    else if (choice3 == 's' || choice3 == 'S')
		    {
			++playerY;
		    }
		    else if (choice3 == 'a' || choice3 == 'A')
		    {
			--playerX;
		    }
		    else if (choice3 == '\n' && mediumFlip [playerX] [playerY] == false)
		    {
			mediumFlip [playerX] [playerY] = true;
			mediumXTemp [turn] = playerX;
			mediumYTemp [turn] = playerY;
			turn++;
		    }
		    else if (choice3 == '\n' && mediumFlip [playerX] [playerY] == true)
		    {
			mediumFlip [playerX] [playerY] = false;
			turn = 0;
			mediumXTemp [turn] = 0;
			mediumYTemp [turn] = 0;
		    }
		}
		else if (playerY == mediumFlip.length - 1)
		{
		    choice3 = c.getChar ();
		    if (choice3 == 'a' || choice3 == 'A')
		    {
			--playerX;
		    }
		    else if (choice3 == 'w' || choice3 == 'W')
		    {
			--playerY;
		    }
		    else if (choice3 == 'd' || choice3 == 'D')
		    {
			++playerX;
		    }
		    else if (choice3 == '\n' && mediumFlip [playerX] [playerY] == false)
		    {
			mediumFlip [playerX] [playerY] = true;
			mediumXTemp [turn] = playerX;
			mediumYTemp [turn] = playerY;
			turn++;
		    }
		    else if (choice3 == '\n' && mediumFlip [playerX] [playerY] == true)
		    {
			mediumFlip [playerX] [playerY] = false;
			turn = 0;
			mediumXTemp [turn] = 0;
			mediumYTemp [turn] = 0;
		    }
		}
		if (turn >= 2)
		{
		    check (mediumXTemp [0], mediumYTemp [0], mediumXTemp [1], mediumYTemp [1]);
		    ++playerTurn;
		}
	    }
	    else if (difficulty == 3)
	    {
		endGame (hardFlip2);
		c.drawRect (339 + playerX * 70, 15 + playerY * 81, 66, 78);
		if (playerX == 0)
		{
		    choice3 = c.getChar ();
		    if (choice3 == 'w' || choice3 == 'W')
		    {
			--playerY;
		    }
		    else if (choice3 == 's' || choice3 == 'S')
		    {
			++playerY;
		    }
		    else if (choice3 == 'd' || choice3 == 'D')
		    {
			++playerX;
		    }
		    else if (choice3 == '\n' && hardFlip [playerX] [playerY] == false)
		    {
			hardFlip [playerX] [playerY] = true;
			hardXTemp [turn] = playerX;
			hardYTemp [turn] = playerY;
			turn++;
		    }
		    else if (choice3 == '\n' && hardFlip [playerX] [playerY] == true)
		    {
			hardFlip [playerX] [playerY] = false;
			turn = 0;
			hardXTemp [turn] = 0;
			hardYTemp [turn] = 0;
		    }
		}
		else if (playerY == 0)
		{
		    choice3 = c.getChar ();
		    if (choice3 == 'a' || choice3 == 'A')
		    {
			--playerX;
		    }
		    else if (choice3 == 's' || choice3 == 'S')
		    {
			++playerY;
		    }
		    else if (choice3 == 'd' || choice3 == 'D')
		    {
			++playerX;
		    }
		    else if (choice3 == '\n' && hardFlip [playerX] [playerY] == false)
		    {
			hardFlip [playerX] [playerY] = true;
			hardXTemp [turn] = playerX;
			hardYTemp [turn] = playerY;
			turn++;
		    }
		    else if (choice3 == '\n' && hardFlip [playerX] [playerY] == true)
		    {
			hardFlip [playerX] [playerY] = false;
			turn = 0;
			hardXTemp [turn] = 0;
			hardYTemp [turn] = 0;
		    }
		}
		else if (playerX > 0 && playerX < hardFlip.length - 1 && playerY > 0 && playerY < hardFlip [0].length - 1)
		{
		    choice3 = c.getChar ();
		    if (choice3 == 'w' || choice3 == 'W')
		    {
			--playerY;
		    }
		    else if (choice3 == 'a' || choice3 == 'A')
		    {
			--playerX;
		    }
		    else if (choice3 == 's' || choice3 == 'S')
		    {
			++playerY;
		    }
		    else if (choice3 == 'd' || choice3 == 'D')
		    {
			++playerX;
		    }
		    else if (choice3 == '\n' && hardFlip [playerX] [playerY] == false)
		    {
			hardFlip [playerX] [playerY] = true;
			hardXTemp [turn] = playerX;
			hardYTemp [turn] = playerY;
			turn++;
		    }
		    else if (choice3 == '\n' && hardFlip [playerX] [playerY] == true)
		    {
			hardFlip [playerX] [playerY] = false;
			turn = 0;
			hardXTemp [turn] = 0;
			hardYTemp [turn] = 0;
		    }
		}
		else if (playerX == hardFlip.length - 1)
		{
		    choice3 = c.getChar ();
		    if (choice3 == 'w' || choice3 == 'W')
		    {
			--playerY;
		    }
		    else if (choice3 == 's' || choice3 == 'S')
		    {
			++playerY;
		    }
		    else if (choice3 == 'a' || choice3 == 'A')
		    {
			--playerX;
		    }
		    else if (choice3 == '\n' && hardFlip [playerX] [playerY] == false)
		    {
			hardFlip [playerX] [playerY] = true;
			hardXTemp [turn] = playerX;
			hardYTemp [turn] = playerY;
			turn++;
		    }
		    else if (choice3 == '\n' && hardFlip [playerX] [playerY] == true)
		    {
			hardFlip [playerX] [playerY] = false;
			turn = 0;
			hardXTemp [turn] = 0;
			hardYTemp [turn] = 0;
		    }
		}
		else if (playerY == hardFlip.length - 1)
		{
		    choice3 = c.getChar ();
		    if (choice3 == 'a' || choice3 == 'A')
		    {
			--playerX;
		    }
		    else if (choice3 == 'w' || choice3 == 'W')
		    {
			--playerY;
		    }
		    else if (choice3 == 'd' || choice3 == 'D')
		    {
			++playerX;
		    }
		    else if (choice3 == '\n' && hardFlip [playerX] [playerY] == false)
		    {
			hardFlip [playerX] [playerY] = true;
			hardXTemp [turn] = playerX;
			hardYTemp [turn] = playerY;
			turn++;

		    }
		    else if (choice3 == '\n' && hardFlip [playerX] [playerY] == true)
		    {
			hardFlip [playerX] [playerY] = false;
			turn = 0;
			hardXTemp [turn] = 0;
			hardYTemp [turn] = 0;
		    }
		}
		if (turn >= 2)
		{
		    check (hardXTemp [0], hardYTemp [0], hardXTemp [1], hardYTemp [1]);
		    ++playerTurn;
		}
	    }
	    if (game != true)
	    {
	    }
	    else
	    {
		break;
	    }
	}
    }

    /*
    Method Name: endGame
    Purpose: used to determine whether the game has ended or not
    Variables:
    -------------------------------------------------------------------------------------------------------------
    |   Name        |   Type        |   Purpose                                                                 |
    -------------------------------------------------------------------------------------------------------------
    | flip          | boolean[] []  |  Represents the status of the boolean variables, easyFlip, easyflip2,     |
    |               |               |  mediumFlip, mediumFlip2, hardFlip, and hardFlip2.                        |
    -------------------------------------------------------------------------------------------------------------
    For loop: using a nested for loop to determine the status of the variable flip and returns the variable game 
    as true or false depending on the outcome
    If - else: used to determine the status of variable game
    */
    private boolean endGame (boolean[] [] flip)
    {
	for (int i = 0 ; i < flip.length ; i++)
	{
	    for (int j = 0 ; j < flip.length ; j++)
	    {
		if (flip [i] [j] == true)
		{
		    game = true;
		}
		else
		{
		    game = false;
		    break;
		}
	    }
	}
	return game;
    }


    /*
    Method Name: check
    Purpose: checks if the user will receive points and also resets the variables to 0
    Variables:
    -------------------------------------------------------------------------------------------------------------
    |   Name        |   Type        |   Purpose                                                                 |
    -------------------------------------------------------------------------------------------------------------
    | x             | int           | Represents the x - index of the first of the 2 elements.                  |
    -------------------------------------------------------------------------------------------------------------
    | y             | int           | Represents the y - index of the first of the 2 elements.                  |
    -------------------------------------------------------------------------------------------------------------
    | x2            | int           | Represents the x - index of the second of the 2 elements.                 |
    -------------------------------------------------------------------------------------------------------------
    | y2            | int           | Represents the y - index of the second of the 2 elements.                 |
    -------------------------------------------------------------------------------------------------------------
    If - else: Since there are different difficulties of the game with different dimensions, an if - else structure
	       involving the difficulties is used to control what type of calculation is done.
	       If-else is also obviously used to determine whether a player gets to have points and which player
	       to give it to.
    For loop: A for loop isn't really necessary here as the array the values that are being changed only have 2
	      elements but a for loop was faster to type up.
    */
    private void check (int x, int y, int x2, int y2)
    {
	if (difficulty == 1)
	{
	    if (easyItems [x] [y] == easyItems [x2] [y2])
	    {
		if (playerTurn % 2 == 0)
		    player1Points += 100;
		else
		    player2Points += 100;
		easyFlip2 [x] [y] = true;
		easyFlip2 [x2] [y2] = true;
	    }
	    else
	    {
		easyFlip [x] [y] = false;
		easyFlip [x2] [y2] = false;
	    }
	}
	else if (difficulty == 2)
	{
	    if (mediumItems [x] [y] == mediumItems [x2] [y2])
	    {
		if (playerTurn % 2 == 0)
		    player1Points += 100;
		else
		    player2Points += 100;
		mediumFlip2 [x] [y] = true;
		mediumFlip2 [x2] [y2] = true;
	    }
	    else
	    {
		mediumFlip [x] [y] = false;
		mediumFlip [x2] [y2] = false;
	    }
	}
	else if (difficulty == 3)
	{
	    if (hardItems [x] [y] == hardItems [x2] [y2])
	    {
		if (playerTurn % 2 == 0)
		    player1Points += 100;
		else
		    player2Points += 100;
		hardFlip2 [x] [y] = true;
		hardFlip2 [x2] [y2] = true;

	    }
	    else
	    {
		hardFlip [x] [y] = false;
		hardFlip [x2] [y2] = false;
	    }
	}
	turn = 0;

	for (int i = 0 ; i < 1 ; i++)
	{
	    easyXTemp [i] = 0;
	    mediumXTemp [i] = 0;
	    hardXTemp [i] = 0;
	    easyYTemp [i] = 0;
	    mediumYTemp [i] = 0;
	    hardYTemp [i] = 0;
	}
    }


    /*
    Method Name: coverCard
    Purpose: To cover the cards with the 2 unflipped versions if a matching pair was found.
    Variables:
    -------------------------------------------------------------------------------------------------------------
    |   Name        |   Type        |   Purpose                                                                 |
    -------------------------------------------------------------------------------------------------------------
    | flip          | boolean       | Checks whether the program should draw a flipped or unflipped card.       |
    -------------------------------------------------------------------------------------------------------------
    | icon          | int           | Checks which icon should be displayed on the card.                        |
    -------------------------------------------------------------------------------------------------------------
    | x             | int           | Holds the x - index of the array in the method.                           |
    -------------------------------------------------------------------------------------------------------------
    | y             | int           | Holds the y - index of the array in the method.                           |
    -------------------------------------------------------------------------------------------------------------
    If - else: Since there are different difficulties of the game with different dimensions, an if - else structure
	       involving the difficulties is used to control what type of calculation is done.
	       An if else structure is also used to check if a card should be flipped or not
    Try - catch: This structure is required to import images.
    */
    private void coverCard (boolean flip, int icon, int x, int y)
    {
	if (flip)
	{
	    if (difficulty == 1)
	    {
		try
		{
		    BufferedImage easyFront = ImageIO.read (new File ("images//easyFront.png"));
		    c.drawImage (easyFront, 360 + x * 145, 10 + y * 165, null);
		}
		catch (IOException e)
		{
		    c.println ("No image found");
		}
		drawIcons (icon, 395 + x * 145, 45 + y * 165);
	    }
	    else if (difficulty == 2)
	    {
		try
		{
		    BufferedImage mediumFront = ImageIO.read (new File ("images//mediumFront.png"));
		    c.drawImage (mediumFront, 330 + x * 93, 10 + y * 108, null);
		}
		catch (IOException e)
		{
		    c.println ("No image found");
		}
		drawIcons (icon, 338 + x * 93, 23 + y * 108);
	    }
	    else if (difficulty == 3)
	    {
		try
		{
		    BufferedImage hardFront = ImageIO.read (new File ("images//hardFront.png"));
		    c.drawImage (hardFront, 340 + x * 70, 15 + y * 81, null);
		}
		catch (IOException e)
		{
		    c.println ("No image found");
		}
		drawIcons (icon, 340 + x * 70, 20 + y * 81);
	    }
	}
	else
	{
	    if (difficulty == 1)
	    {
		try
		{
		    BufferedImage easyBack = ImageIO.read (new File ("images//easyBack.png"));
		    c.drawImage (easyBack, 360 + x * 145, 10 + y * 165, null);
		}
		catch (IOException e)
		{
		    c.println ("No image found");
		}
	    }
	    else if (difficulty == 2)
	    {
		try
		{
		    BufferedImage mediumBack = ImageIO.read (new File ("images//mediumBack.png"));
		    c.drawImage (mediumBack, 330 + x * 93, 10 + y * 108, null);
		}
		catch (IOException e)
		{
		    c.println ("No image found");
		}
	    }
	    else if (difficulty == 3)
	    {
		try
		{
		    BufferedImage hardBack = ImageIO.read (new File ("images//hardBack.png"));
		    c.drawImage (hardBack, 340 + x * 70, 15 + y * 81, null);
		}
		catch (IOException e)
		{
		    c.println ("No image found");
		}
	    }
	}
    }


    /*
    Method Name: flipCard
    Purpose: To flip the cards if 1-2 values in one of the three Flip arrays are equal to true.
    Variables:
    -------------------------------------------------------------------------------------------------------------
    |   Name        |   Type        |   Purpose                                                                 |
    -------------------------------------------------------------------------------------------------------------
    | flip          | boolean       | Checks whether the program should draw a flipped or unflipped card.       |
    -------------------------------------------------------------------------------------------------------------
    | icon          | int           | Checks which icon should be displayed on the card.                        |
    -------------------------------------------------------------------------------------------------------------
    | x             | int           | Holds the x - index of the array in the method.                           |
    -------------------------------------------------------------------------------------------------------------
    | y             | int           | Holds the y - index of the array in the method.                           |
    -------------------------------------------------------------------------------------------------------------
    If - else: Since there are different difficulties of the game with different dimensions, an if - else structure
	       involving the difficulties is used to control what type of calculation is done.
	       An if else structure is also used to check if a card should be flipped or not
    Try - catch: This structure is required to import images.
    */
    private void flipCard (boolean flip, int icon, int x, int y)
    {
	if (!flip)
	{
	    if (difficulty == 1)
	    {
		try
		{
		    BufferedImage easyBack = ImageIO.read (new File ("images//easyBack.png"));
		    c.drawImage (easyBack, 360 + x * 145, 10 + y * 165, null);
		}
		catch (IOException e)
		{
		    c.println ("No image found");
		}
	    }
	    else if (difficulty == 2)
	    {
		try
		{
		    BufferedImage mediumBack = ImageIO.read (new File ("images//mediumBack.png"));
		    c.drawImage (mediumBack, 330 + x * 93, 10 + y * 108, null);
		}
		catch (IOException e)
		{
		    c.println ("No image found");
		}
	    }
	    else if (difficulty == 3)
	    {
		try
		{
		    BufferedImage hardBack = ImageIO.read (new File ("images//hardBack.png"));
		    c.drawImage (hardBack, 340 + x * 70, 15 + y * 81, null);
		}
		catch (IOException e)
		{
		    c.println ("No image found");
		}
	    }
	}
	else if (flip)
	{
	    if (difficulty == 1)
	    {
		try
		{
		    BufferedImage easyFront = ImageIO.read (new File ("images//easyFront.png"));
		    c.drawImage (easyFront, 360 + x * 145, 10 + y * 165, null);
		}
		catch (IOException e)
		{
		    c.println ("No image found");
		}
		drawIcons (icon, 395 + x * 145, 45 + y * 165);
	    }
	    else if (difficulty == 2)
	    {
		try
		{
		    BufferedImage mediumFront = ImageIO.read (new File ("images//mediumFront.png"));
		    c.drawImage (mediumFront, 330 + x * 93, 10 + y * 108, null);
		}
		catch (IOException e)
		{
		    c.println ("No image found");
		}
		drawIcons (icon, 338 + x * 93, 23 + y * 108);
	    }
	    else if (difficulty == 3)
	    {
		try
		{
		    BufferedImage hardFront = ImageIO.read (new File ("images//hardFront.png"));
		    c.drawImage (hardFront, 340 + x * 70, 15 + y * 81, null);
		}
		catch (IOException e)
		{
		    c.println ("No image found");
		}
		drawIcons (icon, 340 + x * 70, 20 + y * 81);
	    }
	}
    }

    /*
    Method Name: turnMaker
    Purpose: Determines which players turn it is and states how many points each player has
    If - else: used to determine which players turn it is and clarifies with a red rectangle
    */
    private void turnMaker ()
    {
	if (playerTurn % 2 == 0)
	    c.setColor (Color.red);
	else
	    c.setColor (Color.black);
	c.fillRect (0, 0, 200, 100);
	if (playerTurn % 2 == 0)
	    c.setColor (Color.black);
	else
	    c.setColor (Color.red);
	c.fillRect (1000, 0, 200, 100);
	c.setColor (Color.white);
	c.drawString ("Player1", 0, 20);
	c.drawString ("Player2", 1000, 20);
	c.drawString ("Points: " + (player1Points / 100), 0, 50);
	c.drawString ("Points: " + (player2Points / 100), 1000, 50);

    }

    /*
    Method Name: endGame
    Purpose: End credit scene for when the game ends and receives user input for name to display in highscore
    Variables:
    -------------------------------------------------------------------------------------------------------------
    |   Name        |   Type        |   Purpose                                                                 |
    -------------------------------------------------------------------------------------------------------------
    | backGame      | BufferedImage | Used to create the background image for the end credit of game.           |
    -------------------------------------------------------------------------------------------------------------
    | name          | String        | Used to receive the name of player with userinput                         |
    -------------------------------------------------------------------------------------------------------------
    | input         | PrintWriter   | Used to write in the file listed                                          |
    -------------------------------------------------------------------------------------------------------------
    Try block: used to allow the importing of images and writing to files
    If - else: used to determine which player would input their name for the highscore
    */
    public void endGame ()
    {
	try
	{
	    BufferedImage backGame = ImageIO.read (new File ("images//background1.png"));
	    c.drawImage (backGame, 0, 0, null);
	}
	catch (IOException e)
	{
	    c.println ("Image not found");
	}
	if (player1Points > player2Points)
	{
	    c.setColor (Color.black);
	    c.drawString ("Congratulations, Player 1! You won the game!", 0, 40);
	    c.drawString ("Please enter your name:", 0, 80);
	    c.setCursor (4, 37);
	    String name = c.readLine ();
	    PrintWriter input;
	    try
	    {
		input = new PrintWriter (new FileWriter ("highscore.txt"));
		input.println (name);
		input.println (player1Points / 100);
		input.close ();
	    }
	    catch (IOException e)
	    {
	    }
	}
	else if (player2Points > player1Points)
	{
	    c.setColor (Color.black);
	    c.drawString ("Congratulations, Player 2! You won the game!", 0, 40);
	    c.drawString ("Please enter your name:", 0, 80);
	    c.setCursor (4, 37);
	    String name = c.readLine ();
	    PrintWriter input;
	    try
	    {
		input = new PrintWriter (new FileWriter ("highscore.txt"));
		input.println (name);
		input.println (player2Points / 100);
		input.close ();
	    }
	    catch (IOException e)
	    {
	    }
	}
	else if (player1Points == player2Points)
	{
	    c.setColor (Color.black);
	    c.drawString ("Draw! Better luck next time to be on theleader board", 20, 200);
	}
	pauseProgram ();
    }

    /*
    Method Name: restGame
    Purpose: Resets the game to it's original state
    If statements: Used to determine which mode to reset depending on which mode was player
    For loops: Using nested for loops to reset the status of flip variables to false
    */
    public void resetGame ()
    {
	if (difficulty == 1)
	{
	    for (int i = 0 ; i < easyFlip2.length ; i++)
	    {
		for (int j = 0 ; j < easyFlip2.length ; j++)
		{
		    easyFlip [i] [j] = false;
		    easyFlip2 [i] [j] = false;
		}
	    }
	}
	if (difficulty == 2)
	{
	    for (int i = 0 ; i < mediumFlip2.length ; i++)
	    {
		for (int j = 0 ; j < mediumFlip2.length ; j++)
		{
		    mediumFlip [i] [j] = false;
		    mediumFlip2 [i] [j] = false;
		}
	    }
	}
	if (difficulty == 3)
	{
	    for (int i = 0 ; i < hardFlip2.length ; i++)
	    {
		for (int j = 0 ; j < hardFlip2.length ; j++)
		{
		    hardFlip [i] [j] = false;
		    hardFlip2 [i] [j] = false;
		}
	    }
	}
	player1Points = 0;
	player2Points = 0;
    }

    /*
    Method Name: instructions
    Purpose: Prints the instruction of the game to the user incase they don't know how to play
    -------------------------------------------------------------------------------------------------------------
    |   Name        |   Type        |   Purpose                                                                 |
    -------------------------------------------------------------------------------------------------------------
    | backImage     | BufferedImage | Used to import the images to the console                                  |
    -------------------------------------------------------------------------------------------------------------
    Try block: used to allow the import of images to the console
    */
    public void instructions ()
    {
	c.clear ();
	try
	{
	    BufferedImage backImage = ImageIO.read (new File ("images//background2.png"));
	    c.drawImage (backImage, 0, 0, null);
	    BufferedImage scrollImage = ImageIO.read (new File ("images//scroll1.png"));
	    c.drawImage (scrollImage, 400, 0, null);
	}
	catch (IOException e)
	{
	    c.println ("No image found");
	}
	c.drawString ("Concentration is a game", 460, 90);
	c.drawString ("where you select two ", 460, 115);
	c.drawString ("cards. If the two ", 460, 140);
	c.drawString ("icons match, you get a", 460, 165);
	c.drawString ("point! This is a 2", 460, 195);
	c.drawString ("player game. So try and ", 460, 220);
	c.drawString ("beat your opponent. Use", 460, 245);
	c.drawString ("the WASD keys to move", 460, 270);
	c.drawString ("& the enter key to select", 460, 295);
	c.drawString ("a card. Good luck! If", 460, 320);
	c.drawString ("you beat your opponent,", 460, 345);
	c.drawString ("your score will be saved", 460, 370);
	c.drawString ("on the leaderboard.", 460, 395);

	pauseProgram ();
    }

    /*
    Method Name: highscore
    Purpose: Read and displays the file highscore.txt and displays the scores
    Variables:
    -------------------------------------------------------------------------------------------------------------
    |   Name        |   Type        |   Purpose                                                                 |
    -------------------------------------------------------------------------------------------------------------
    | k             | int           | used to determine where the info of the files is printed                  |
    -------------------------------------------------------------------------------------------------------------
    | backImage     | BufferedImage | Used to import the images to the console                                  |
    -------------------------------------------------------------------------------------------------------------
    | scrollImage   | BufferedImage | Used to import the scroll image to the console                            |
    -------------------------------------------------------------------------------------------------------------
    | line          | String        | Determines which line it's reading                                        |
    -------------------------------------------------------------------------------------------------------------
    | count         | int           | Determines the amount of lines in the file                                |
    -------------------------------------------------------------------------------------------------------------
    | score         | int[]         | Used to store the values of the scores of the game                        |
    -------------------------------------------------------------------------------------------------------------
    | name          | String[]      | Used to store the names of the players                                    |
    -------------------------------------------------------------------------------------------------------------
    | temp          | int, String   | Used to help manually sort the arrays in highest to lowest scores         |
    -------------------------------------------------------------------------------------------------------------
    Try block: Allows the code to import images, and read files
    For loops: Using nested for loops to organize the scores and names of the players
    If - else: Used to determine what to print or what to read
    */
    public void highscore ()
    {
	c.clear ();
	int k = 115;
	try
	{
	    BufferedImage backImage = ImageIO.read (new File ("images//background2.png"));
	    c.drawImage (backImage, 0, 0, null);
	    BufferedImage scrollImage = ImageIO.read (new File ("images//scroll1.png"));
	    c.drawImage (scrollImage, 400, 0, null);
	}
	catch (IOException e)
	{
	    c.println ("No image found");
	}
	c.setColor (Color.black);
	c.setFont (new Font ("Times New Roman", 20, 35));
	c.drawString ("Leaderboard", 500, 80);
	BufferedReader input;
	String line = "";
	int count = 0;
	try
	{
	    input = new BufferedReader(new FileReader("highscore.txt"));
	    while(true)
	    {
		if(input.readLine()!=null)
		{
		    count++;
		}
		else
		{
		    break;
		}
	    }
	}
	catch (IOException e)
	{
	}
	if(count !=0)
	{
	    try
	    {
		int [] score = new int[count];
		String [] name = new String[count];
		int temp;
		String temp1;
		input = new BufferedReader(new FileReader("highscore.txt"));
		for(int i = 0; i < count; i++)
		{
		    if(i%2 == 0)
		    {
			name[i/2] = input.readLine();
		    }
		    if(i%2 != 0)
		    {
		    score[i/2] = Integer.parseInt(input.readLine());
		    }
		}
		for(int q = 0; q < count-1; q++)
		{
		    for(int r = 0; r <count-1; r++)
		    {
			if(score[r] < score[r+1])
			{
			    temp = score[r];
			    score[r] = score[r+1];
			    score[r+1] = temp;
			    temp1 = name[r];
			    name[r] = name[r+1];
			    name[r+1] = temp1;
			}
		    }
		}
		
		for(int j = 0; j <= (count-1)/2; j++)
		{
		    c.drawString(name[j]+"      "+score[j],485,k);
		    k+=35;
		}
	    }
	    catch (IOException e)
	    {
	    }
	}
	else
	{
	}
	pauseProgram ();
    }

    /*
    Method Name: goodbye
    Purpose: Goodbye screen for when user wants to exit the game
    Variables:
    -------------------------------------------------------------------------------------------------------------
    |   Name        |   Type        |   Purpose                                                                 |
    -------------------------------------------------------------------------------------------------------------
    | backImage     | BufferedImage | Used to import the images to the console                                  |
    -------------------------------------------------------------------------------------------------------------
    Try block: used to import the images used
    */
    public void goodbye ()
    {
	try
	{
	    BufferedImage goodbye = ImageIO.read (new File ("images//background3.png"));
	    c.drawImage (goodbye, 0, 0, null);
	}
	catch (IOException e)
	{
	    c.println ("No image found");
	}
	c.setColor (Color.white);
	c.drawString ("Thank you for playing, adventurer. Until next time...", 10, 650);
    }


    public static void main (String[] args)
    {
	ConcentrationISP d = new ConcentrationISP ();
	d.splashScreen ();
	while (true)
	{
	    d.mainMenu ();
	    if (d.menuOption == 1)
	    {
		d.difficultySelector ();
		d.deckShuffle ();
		d.concentration ();
		d.endGame ();
		d.resetGame ();
	    }
	    if (d.menuOption == 2)
	    {
		d.instructions ();
	    }
	    if (d.menuOption == 3)
	    {
		d.highscore ();
	    }
	    if (d.menuOption == 4)
	    {
		d.goodbye ();
		break;
	    }
	}
	// Place your program here.  'c' is the output console
    } // main method
} // ConcentrationISP class


